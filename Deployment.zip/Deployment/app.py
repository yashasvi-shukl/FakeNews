# -*- coding: utf-8 -*-
"""
Created on Tue Feb 22 12:50:15 2022

@author: Monster
"""


import streamlit as st
import nltk
from nltk.tokenize import word_tokenize
#from tensorflow.keras.preprocessing.sequence import pad_sequences
import pickle
import re
#nltk.download()
import string
from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
import numpy as np
import time

from Cleaning import *



#=================================================================================

vectorizer = pickle.load(open("Count_vector.pkl", "rb"))
    
#=================================================================================


@st.cache(allow_output_mutation=True)
def Load_model():
    model = pickle.load(open("LR_model.pkl", "rb"))
    return model



def cleaning(article):
    article = article.lower()
    article = remove_links(article)
    article = remove_HTMLtags(article)
    article = decontracting(article)
    article = remove_stopwords(article)
    article = remove_specialChar(article)
    article = lemma(article)
    return article


#=================================================================================


def predict(clean_text):
    sequences = vectorizer.transform([clean_text])
    #data = pad_sequences(sequences, padding = 'post', maxlen = MAX_SEQUENCE_LENGTH)
    prediction = model.predict(sequences)
    prediction = np.round(prediction)
    
    
    if prediction == 1:
        st.success("This is Real News.")
        # c1, c2, c3 = st.columns([0.2, 5, 0.2])
        # c2.image("Real.jpg", use_column_width=True)
        # #c2.image(use_column_width = True)
    elif prediction == 0:
        st.warning("This is a Fake News.")
        # c1, c2, c3 = st.columns([0.2, 5, 0.2])
        # c2.image("FakeNews.jpg", use_column_width=True)
        
#=================================================================================

if __name__ == '__main__':
    
    
    #background = Image.open()
    col1, col2, col3 = st.columns([0.2, 5, 0.2])
    col2.image("news.jpg", use_column_width=True)
    
    st.title('Fake News Classification')
    #st.subheader("Enter the News article below:")
    sentence = st.text_area("Enter the News article below:",height=200)
    c1, c2, c3 = st.columns([0.2, 5, 0.2])
    predict_btt = st.button("Predict", )
    model = Load_model()
    
    
    if predict_btt:
        clean_text = cleaning(sentence)
        
        if len(clean_text.split()) == 0:
            st.error("Ohh No!! You forgot to enter the article.")
            
        elif len(clean_text.split()) <= 20:
            st.warning("Number of usefull words is less than expected. Still I'm trying to classify...")
            time.sleep(2)
            predict(clean_text)
            # st.text("Usefull words : "+clean_text)
            
        else: 
            predict(clean_text)