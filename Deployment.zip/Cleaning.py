# -*- coding: utf-8 -*-
"""
Created on Sun Feb 20 18:30:12 2022

@author: Monster
"""

from nltk.corpus import stopwords

stop_words = set(['i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', "you're", "you've", "you'll", "you'd", 
              'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she', "she's", 'her', 'hers',
              'herself', 'it', "it's", 'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which',
              'who', 'whom', 'this', 'that', "that'll", 'these', 'those', 'am', 'is', 'are', 'was', 'were', 'be', 'been',
              'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if',
               'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 
               'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off',
               'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all',
               'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own',
               'same', 'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', "don't", 'should', "should've",
                'now', 'd', 'll', 'm', 'o', 're', 've', 'y', 'ain', 'aren', "aren't", 'couldn', "couldn't", 'didn', "didn't",
                 'doesn', "doesn't", 'hadn', "hadn't", 'hasn', "hasn't", 'haven', "haven't", 'isn', "isn't", 'ma', 'mightn',
                 "mightn't", 'mustn', "mustn't", 'needn', "needn't", 'shan', "shan't", 'shouldn', "shouldn't", 'wasn', "wasn't",
                 'weren', "weren't", 'won', "won't", 'wouldn', "wouldn't", "from", "subject", "re", "edu", "use", "said", "reuters"])
stop_words.remove("no")
stop_words.remove("not")
stop_words.remove("very")
stop_words.remove('nor')

def remove_stopwords(article):
    final_article = ''
    for token in article.split():
        if len(token)>3 and token not in stop_words:
            final_article += token + ' '
    return final_article.strip()


## -------------------------------------------------------------------------------

#Removing words with digits and special characters
def remove_specialChar(sentence):
    article = ""
    for word in sentence.split():
        word = str(word)
        word = re.sub("\S*\d\S*", "", word)
        word = re.sub('[^A-Za-z0-9]+', " ", word)
        word = word.replace(" ", "")
        article = article + word + ' '
    return article.strip()

##--------------------------------------------------------------------------------

# Removing links
import re
def remove_links(article):
    return re.sub("http\S+", "", article )

##--------------------------------------------------------------------------------

# Removing html tags
from bs4 import BeautifulSoup
def remove_HTMLtags(article):
    soup = BeautifulSoup(article, 'html.parser')
    text = soup.get_text()
    return text

##--------------------------------------------------------------------------------

# Converting contraction words like was't, don't, etc. into normal english words like was not, do not etc.
def decontracting(article):
    # Specific
    article = re.sub("won't", "will not", article)
    article = re.sub("can't", "can not", article)
    
    # General
    article = re.sub(r"n\'t", " not", article)
    article = re.sub(r"\'re", " are", article)
    article = re.sub(r"\'s", " is", article)
    article = re.sub(r"\'d", " would", article)
    article = re.sub(r"\'ll", " will", article)
    article = re.sub(r"\'t", " not", article)
    article = re.sub(r"\'ve", " have", article)
    article = re.sub(r"\'m", " am", article)
    return article

##--------------------------------------------------------------------------------


from nltk.stem import WordNetLemmatizer
def lemma(article):
    lem_article = ""
    lemmatizer = WordNetLemmatizer()
    for word in article.split():
        lem_article += lemmatizer.lemmatize(word) + ' '
    return lem_article.strip()

##--------------------------------------------------------------------------------



